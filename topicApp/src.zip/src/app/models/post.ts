export interface Post {
    id: number;
    topicId: number;
    name: string;
    description: string
}
