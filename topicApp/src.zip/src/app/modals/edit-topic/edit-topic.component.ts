import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-edit-topic',
  templateUrl: './edit-topic.component.html',
  styleUrls: ['./edit-topic.component.scss'],
})
export class EditTopicComponent implements OnInit {

  constructor() { }

  ngOnInit() {}

}
